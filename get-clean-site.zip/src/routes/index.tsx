import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Clock, Sparkles, Star, Phone, Check, ShieldCheck, Heart, Gem, Wallet, Send } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Get Clean — клінінг преміум-класу у Тернополі" },
      { name: "description", content: "Професійний клінінг квартир, будинків та офісів у Тернополі. Безкоштовний розрахунок." },
      { property: "og:title", content: "Get Clean — клінінг преміум-класу у Тернополі" },
      { property: "og:description", content: "Бездоганна чистота без компромісів. Безкоштовний розрахунок вартості." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const PHONE = "tel:+380970020282";
const services = [
  ["Генеральне прибирання Pro", "Глибоке прибирання всієї оселі: кухня, санвузли, шафи, плінтуси, важкодоступні місця."],
  ["Підтримуюче прибирання квартир і будинків", "Регулярна чистота: підлоги, пил, кухня, санвузол і свіже повітря у домі."],
  ["Прибирання офісів і комерційних приміщень", "До приходу команди або після робочого дня. Без запахів і слідів на склі."],
  ["Миття вікон та жалюзі", "Скло без розводів і відбитків, жалюзі — поштучно, до світла."],
  ["Прибирання після ремонту", "Будівельний пил, сліди затирки та клею — повертаємо дім до життя."],
];
const why = [
  [Clock, "Приходимо вчасно, завжди", "Узгоджений час — це домовленість, а не побажання. Ми його тримаємо."],
  [Sparkles, "Чистота до блиску", "Ви бачите результат там, де зазвичай його не помічають."],
  [ShieldCheck, "Ввічлива, професійна команда", "Спокійні, акуратні люди, яким безпечно відкрити двері дому."],
  [Gem, "Ретельність: кожен куточок", "Кухня, санвузол, скло, плінтуси, шви — без пропущених зон."],
  [Wallet, "Чесна вартість наперед", "Сума, яку назвали, не змінюється після прибирання."],
  [Heart, "Бізнесом керує жінка, яка цінує деталі", "Особиста відповідальність за кожне прибирання — від першого дзвінка."],
] as const;
const reviews = [
  ["Велика подяка вашій команді! Ви перевершили наші очікування, прибирання було виконано швидко та дуже якісно. Якщо клінінг, то тільки до вас.", "The Myaso"],
  ["Безкоштовний розрахунок вартості. Пунктуальні та ввічливі клінери, які прибирають до блиску.", "Anna Vasyliv"],
  ["Замовляла генеральне прибирання Pro та миття вікон із жалюзі. Команда пунктуальна, професійна, ретельно прибрала кожен куточок.", "Svitlana Stoyko"],
];

const btn = "inline-flex items-center justify-center gap-2 rounded-full px-7 py-3.5 font-semibold transition-all";
const primary = `${btn} bg-primary text-primary-foreground hover:opacity-90 shadow-lg`;
const ghost = `${btn} border border-border bg-card text-foreground hover:bg-secondary`;

function Eyebrow({ children }: { children: string }) {
  return <p className="mb-3 text-sm font-semibold uppercase tracking-[0.2em] text-primary">{children}</p>;
}

function BeforeAfter() {
  const [v, setV] = useState(50);
  return (
    <div className="relative aspect-[16/10] w-full select-none overflow-hidden rounded-3xl shadow-xl">
      <img src="/images/getclean-ba-living-after.png" alt="Після" className="absolute inset-0 h-full w-full object-cover" />
      <img src="/images/getclean-ba-living-before.png" alt="До" className="absolute inset-0 h-full w-full object-cover" style={{ clipPath: `inset(0 ${100 - v}% 0 0)` }} />
      <div className="absolute inset-y-0 w-1 bg-card" style={{ left: `${v}%` }} />
      <span className="absolute left-4 top-4 rounded-full bg-card/90 px-3 py-1 text-sm font-semibold">До</span>
      <span className="absolute right-4 top-4 rounded-full bg-card/90 px-3 py-1 text-sm font-semibold">Після</span>
      <input type="range" min={0} max={100} value={v} onChange={(e) => setV(+e.target.value)} aria-label="Порівняти" className="absolute inset-0 h-full w-full cursor-ew-resize opacity-0" />
    </div>
  );
}

function QuoteForm() {
  const [sent, setSent] = useState(false);
  const submit = (e: FormEvent) => { e.preventDefault(); setSent(true); };
  const field = "w-full rounded-xl border border-input bg-background px-4 py-3 outline-none focus:ring-2 focus:ring-ring";
  if (sent) return <div className="rounded-3xl bg-card p-10 text-center shadow-xl"><Check className="mx-auto mb-4 h-12 w-12 text-primary" /><h3 className="text-3xl font-semibold">Дякуємо!</h3><p className="mt-2 text-muted-foreground">Ми зв'яжемося з вами протягом 15 хвилин у робочий час.</p></div>;
  return (
    <form onSubmit={submit} className="space-y-4 rounded-3xl bg-card p-8 text-card-foreground shadow-xl">
      <label className="block"><span className="mb-1 block text-sm font-medium">Ім'я</span><input required className={field} /></label>
      <label className="block"><span className="mb-1 block text-sm font-medium">Телефон</span><input required type="tel" placeholder="+380" className={field} /></label>
      <label className="block"><span className="mb-1 block text-sm font-medium">Тип послуги</span>
        <select required defaultValue="" className={field}><option value="" disabled>Оберіть послугу</option>{services.map(([t]) => <option key={t}>{t}</option>)}</select></label>
      <label className="block"><span className="mb-1 block text-sm font-medium">Повідомлення (необов'язково)</span><textarea rows={3} className={field} /></label>
      <button className={`${primary} w-full`}>Отримати розрахунок</button>
      <p className="text-center text-sm text-muted-foreground">Відповімо протягом 15 хвилин у робочий час.</p>
    </form>
  );
}

function Index() {
  return (
    <main className="bg-background font-sans text-foreground">
      <header className="absolute inset-x-0 top-0 z-10 mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <span className="font-display text-2xl font-bold text-primary-foreground">Get Clean</span>
        <a href={PHONE} className="hidden items-center gap-2 font-semibold text-primary-foreground sm:flex"><Phone className="h-4 w-4" />097 002 0282</a>
      </header>

      <section className="relative flex min-h-[92vh] items-center overflow-hidden">
        <img src="/images/getclean-hero.png" alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-foreground/85 via-foreground/55 to-transparent" />
        <div className="relative mx-auto w-full max-w-6xl px-6 py-32 text-primary-foreground">
          <p className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-accent">Клінінг преміум-класу · Тернопіль</p>
          <h1 className="max-w-2xl text-5xl font-semibold leading-[1.05] md:text-7xl">Бездоганна чистота. Без компромісів.</h1>
          <p className="mt-6 max-w-lg text-lg opacity-90">Професійний клінінг квартир, будинків та офісів у Тернополі. Пунктуальні, ввічливі, до блиску.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#quote" className={`${btn} bg-accent text-accent-foreground hover:opacity-90`}>Отримати безкоштовний розрахунок</a>
            <a href={PHONE} className={`${btn} border border-primary-foreground/40 hover:bg-primary-foreground/10`}><Phone className="h-4 w-4" />Подзвонити 097 002 0282</a>
          </div>
          <p className="mt-6 text-sm opacity-80">● Обмежена кількість вільних дат цього тижня</p>
          <ul className="mt-10 flex flex-wrap gap-x-8 gap-y-2 text-sm font-medium">
            <li className="flex items-center gap-1"><Star className="h-4 w-4 fill-accent text-accent" />4,8 на Google</li>
            <li>25 відгуків</li><li>Безкоштовний розрахунок</li><li>Команда з 6+ років досвіду</li>
          </ul>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 px-6 py-20 sm:grid-cols-2 lg:grid-cols-4">
        {[["Пунктуальність", "Приходимо вчасно — час узгоджуємо заздалегідь."], ["Ввічливі клінери", "Делікатні, спокійні, у формі та зі своїм обладнанням."], ["Ретельність до кожного куточка", "Плінтуси, шви, скло — нічого не залишаємо на потім."], ["Безкоштовна оцінка вартості", "Порахуємо наперед, без візиту — сума не зміниться."]].map(([t, d]) => (
          <div key={t}><h3 className="text-2xl font-semibold">{t}</h3><p className="mt-2 text-muted-foreground">{d}</p></div>
        ))}
      </section>

      <section className="bg-secondary py-24">
        <div className="mx-auto max-w-6xl px-6">
          <Eyebrow>Послуги</Eyebrow>
          <h2 className="max-w-2xl text-4xl font-semibold md:text-5xl">Прибирання, яке відчуваєш з порога</h2>
          <p className="mt-4 text-muted-foreground">Оберіть формат — решту зробимо ми. Прозора вартість, узгоджена наперед.</p>
          <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {services.map(([t, d], i) => (
              <div key={t} className="flex flex-col rounded-3xl bg-card p-8 shadow-sm transition-shadow hover:shadow-xl">
                <span className="font-display text-4xl text-accent">0{i + 1}</span>
                <h3 className="mt-4 text-2xl font-semibold">{t}</h3>
                <p className="mt-3 flex-1 text-muted-foreground">{d}</p>
                <a href="#quote" className="mt-6 font-semibold text-primary hover:underline">Замовити →</a>
              </div>
            ))}
            <div className="flex items-center rounded-3xl border border-dashed border-primary/40 p-8 text-muted-foreground">Не знаєте, що саме потрібно? Ми підкажемо під час безкоштовного розрахунку.</div>
          </div>
        </div>
      </section>

      <section className="bg-primary py-20 text-center text-primary-foreground">
        <h2 className="text-4xl font-semibold">Обмежена кількість вільних дат цього тижня</h2>
        <p className="mx-auto mt-3 max-w-xl opacity-85">Забронюйте зручний день — розрахунок безкоштовний і ні до чого не зобов'язує.</p>
        <a href="#quote" className={`${btn} mt-8 bg-accent text-accent-foreground`}>Замовити прибирання</a>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-24">
        <Eyebrow>Як це працює</Eyebrow>
        <h2 className="text-4xl font-semibold md:text-5xl">Три кроки до бездоганної чистоти</h2>
        <div className="mt-12 grid gap-10 md:grid-cols-3">
          {[["Залиште заявку або зателефонуйте", "Хвилина на форму або дзвінок — розкажете про помешкання та побажання."], ["Отримайте безкоштовний розрахунок", "Порахуємо вартість наперед і запропонуємо зручний для вас час."], ["Насолоджуйтесь бездоганною чистотою", "Команда приїде вчасно, зробить свою справу й залишить по собі тишу та світло."]].map(([t, d], i) => (
            <div key={t} className="border-t-2 border-accent pt-6"><span className="font-display text-5xl text-primary">0{i + 1}</span><h3 className="mt-3 text-2xl font-semibold">{t}</h3><p className="mt-2 text-muted-foreground">{d}</p></div>
          ))}
        </div>
        <div className="mt-12 flex flex-wrap items-center gap-6"><a href="#quote" className={primary}>Отримати безкоштовний розрахунок</a><span className="text-muted-foreground">Працюємо Пн–Нд з 08:00</span></div>
      </section>

      <section className="bg-secondary py-24">
        <div className="mx-auto max-w-5xl px-6 text-center">
          <Eyebrow>До / Після</Eyebrow>
          <h2 className="text-4xl font-semibold md:text-5xl">Різниця, яку видно</h2>
          <p className="mb-10 mt-3 text-muted-foreground">Потягніть повзунок, щоб побачити результат нашої роботи.</p>
          <BeforeAfter />
          <h3 className="mt-16 text-3xl font-semibold">Ваш дім заслуговує на таку чистоту</h3>
          <a href="#quote" className={`${primary} mt-6`}>Замовити прибирання</a>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-24">
        <Eyebrow>Чому Get Clean</Eyebrow>
        <h2 className="text-4xl font-semibold md:text-5xl">Те, за що нас обирають</h2>
        <p className="mt-3 text-muted-foreground">Кожен пункт — не обіцянка з реклами, а те, що клієнти пишуть у відгуках.</p>
        <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {why.map(([Icon, t, d]) => (
            <div key={t}><div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary text-primary"><Icon className="h-6 w-6" /></div><h3 className="text-2xl font-semibold">{t}</h3><p className="mt-2 text-muted-foreground">{d}</p></div>
          ))}
        </div>
      </section>

      <section className="bg-foreground py-24 text-background">
        <div className="mx-auto max-w-6xl px-6">
          <p className="mb-3 text-sm font-semibold uppercase tracking-[0.2em] text-accent">Відгуки</p>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h2 className="text-4xl font-semibold md:text-5xl">Нас рекомендують</h2>
            <p><span className="font-display text-4xl text-accent">4,8 / 5</span> · 25 відгуків Google</p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {reviews.map(([t, a]) => (
              <figure key={a} className="rounded-3xl border border-background/15 p-8">
                <div className="mb-4 flex gap-1">{[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 fill-accent text-accent" />)}</div>
                <blockquote className="opacity-90">{t}</blockquote>
                <figcaption className="mt-6 font-semibold">{a}<span className="block text-sm font-normal opacity-60">Відгук на Google</span></figcaption>
              </figure>
            ))}
          </div>
          <a href="https://www.google.com/search?q=Get+Clean+Тернопіль+відгуки" target="_blank" rel="noreferrer" className="mt-10 inline-block font-semibold text-accent hover:underline">Дивитись усі відгуки на Google →</a>
        </div>
      </section>

      <section id="quote" className="mx-auto grid max-w-6xl gap-12 px-6 py-24 lg:grid-cols-2">
        <div>
          <Eyebrow>Безкоштовний розрахунок</Eyebrow>
          <h2 className="text-4xl font-semibold md:text-5xl">Готові до ідеальної чистоти?</h2>
          <p className="mt-4 text-muted-foreground">Заповніть кілька полів — і ми повернемось із вартістю та вільними датами.</p>
          <ul className="mt-8 space-y-3">
            {["Відповімо протягом 15 хвилин у робочий час.", "Використовуємо ваш номер лише для розрахунку вартості.", "Обмежена кількість вільних дат цього тижня"].map((t) => <li key={t} className="flex gap-3"><Check className="h-5 w-5 shrink-0 text-primary" />{t}</li>)}
          </ul>
          <a href={PHONE} className={`${ghost} mt-8`}><Phone className="h-4 w-4" />Подзвонити 097 002 0282</a>
        </div>
        <QuoteForm />
      </section>

      <footer className="border-t border-border py-10">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-6">
          <span className="font-display text-2xl font-bold text-primary">Get Clean</span>
          <nav className="flex flex-wrap gap-6 text-sm font-medium">
            <a href="https://t.me/getclean_ternopil" className="flex items-center gap-1 hover:text-primary"><Send className="h-4 w-4" />Telegram</a>
            <a href="viber://chat?number=%2B380970020282" className="hover:text-primary">Viber</a>
            <a href="https://instagram.com/getclean.ternopil" className="hover:text-primary">Instagram</a>
            <a href={PHONE} className="hover:text-primary">Подзвонити</a>
          </nav>
        </div>
      </footer>
    </main>
  );
}
